import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import express from "express";
import { registerFilesystemTools } from "./tools/filesystem.js";
import { registerProcessTools } from "./tools/process.js";
import { registerConfigTools } from "./tools/configTools.js";
import { getAllowedRoot } from "./security.js";

function buildServer(): McpServer {
  const server = new McpServer({
    name: "commander-mcp-server",
    version: "1.0.0",
  });

  registerFilesystemTools(server);
  registerProcessTools(server);
  registerConfigTools(server);

  return server;
}

async function runStdio(): Promise<void> {
  const server = buildServer();
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error(`commander-mcp-server running on stdio (root: ${getAllowedRoot()})`);
}

async function runHTTP(): Promise<void> {
  const app = express();
  app.use(express.json({ limit: "10mb" }));

  app.get("/health", (_req, res) => {
    res.json({ status: "ok", server: "commander-mcp-server", allowedRoot: getAllowedRoot() });
  });

  app.post("/mcp", async (req, res) => {
    // New server + transport per request: stateless, avoids request-id
    // collisions across concurrent callers hitting the gateway.
    const server = buildServer();
    const transport = new StreamableHTTPServerTransport({
      sessionIdGenerator: undefined,
      enableJsonResponse: true,
    });
    res.on("close", () => {
      transport.close();
      server.close();
    });
    await server.connect(transport);
    await transport.handleRequest(req, res, req.body);
  });

  // 8107 is already FusionAL-Recall in your compose.yaml — defaulting to
  // 8108 (next open slot after gateway/bi/api/content/intel/github/recall).
  const port = parseInt(process.env.PORT || "8108", 10);
  app.listen(port, () => {
    console.error(`commander-mcp-server running on http://0.0.0.0:${port}/mcp (root: ${getAllowedRoot()})`);
  });
}

const transportMode = process.env.TRANSPORT || "stdio";
if (transportMode === "http") {
  runHTTP().catch((err) => {
    console.error("Fatal server error:", err);
    process.exit(1);
  });
} else {
  runStdio().catch((err) => {
    console.error("Fatal server error:", err);
    process.exit(1);
  });
}
